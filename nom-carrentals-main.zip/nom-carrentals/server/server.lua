local Framework = exports['nom-lib']:GetLibrary()

RegisterServerEvent('nom-carrentals:giveMoney')
AddEventHandler('nom-carrentals:giveMoney', function()
    local src = source
    Framework.AddMoney(src, Config.PaymentMethod, Config.RefundFee, 'nom-carrentals:giveMoney')
end)


RegisterServerEvent('nom-carrentals:removeMoney')
AddEventHandler('nom-carrentals:removeMoney', function(carPrice)
    local src = source
    local playerMoney = Framework.GetMoney(src, Config.PaymentMethod)

    if not playerMoney or tonumber(playerMoney) < tonumber(carPrice) then
        TriggerClientEvent("nom-carrentals:enoughMoney", src)
    else
        Framework.RemoveMoney(src, Config.PaymentMethod, tonumber(carPrice))
        TriggerClientEvent("nom-carrentals:removeCar", src)
        if Config.Notify == "nom" then
            TriggerClientEvent('nom-notify:show', src, "You have successfully rented the car!", "success", 5000)
        else
            Framework.Notify(src, "You have successfully rented the car!", "success", 5000)
        end
    end
end)

RegisterServerEvent("nom-carrentals:validateRental")
AddEventHandler("nom-carrentals:validateRental", function(car, price, counter)
    local src = source
    local playerMoney = Framework.GetMoney(src, Config.PaymentMethod)

    if not playerMoney or tonumber(playerMoney) < tonumber(price) then
        TriggerClientEvent("nom-carrentals:enoughMoney", src)
    else
        Framework.RemoveMoney(src, Config.PaymentMethod, tonumber(price))
        TriggerClientEvent("nom-carrentals:spawnCar", src, car, counter, price)
        if Config.Notify == "nom" then
            TriggerClientEvent('nom-notify:show', src, "You have successfully rented the car!", "success", 5000)
        else
            Framework.Notify(src, "You have successfully rented the car!", "success", 5000)
        end
    end
end)