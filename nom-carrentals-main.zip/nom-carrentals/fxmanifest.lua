fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'nomm3rZz'
description 'Transportation rental script(QBX/QB)'
version '1.0.0'

ui_page 'ui/index.html'

server_script 'server/*.lua'
client_script 'client/*.lua'

shared_script {
    '@ox_lib/init.lua',
    'config.lua'
}

files {
    'ui/index.html',
    'ui/main.css',
    'ui/index.js',
    'ui/images/*.png',
    'ui/images/*.jpg'
}

dependencies {
    'nom-lib',
    'ox_lib'
}