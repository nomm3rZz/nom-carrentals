$(function () {
    function display(bool) {
        if (bool) {
            $("#container").show();
        } else {
            $("#container").hide();
        }
    }

    display(false);

    window.addEventListener('message', function(event) {
        var func = event.data;
        if (func.type === "ui") {
            for (let i = 0; i < func.car_names.length; i++) {
                let carNameElement = document.getElementById("carname" + (i + 1));
                if (carNameElement) {
                    carNameElement.innerHTML = func.car_names[i];
                } else {
                    //console.error("Element carname" + (i + 1) + " not found.");
                }
            }

            for (let i = 0; i < func.car_prices.length; i++) {
                let carPriceElement = document.getElementById("carlistprice" + (i + 1));
                if (carPriceElement) {
                    carPriceElement.innerHTML = func.car_prices[i] + "$";
                } else {
                    //console.error("Element carlistprice" + (i + 1) + " not found.");
                }
            }

            if (func.status == true) {
                display(true);
            } else {
                display(false);
            }
        }
    });

    var spawnedCarName;
    var spawnedCarPrice;
    var counter = 0;

    function clear() {
        let centerpic = document.getElementById("centerpic");
        let carnameCenter = document.getElementById("carnameCenter");
        let timeText = document.getElementById("timeText");
        
        if (centerpic) centerpic.style.display = "none";
        if (carnameCenter) carnameCenter.style.display = "none";
        if (timeText) timeText.innerHTML = "0";
        counter = 0;
    }

    $("#close").click(function () {
        $.post('https://nom-carrentals/close', JSON.stringify({}));
        clear();
    });

    $("#rentCar").click(function () {
        $.post('https://nom-carrentals/rentCar', JSON.stringify({ spawnedCarName, counter, spawnedCarPrice }));
        clear();
    });

    $("#carlistrentbutton1").click(function() {
        let centerpic = document.getElementById("centerpic");
        let carnameCenter = document.getElementById("carnameCenter");
        let carname1 = document.getElementById("carname1");
        let carlistimg1 = document.getElementById("carlistimg1");

        if (centerpic && carnameCenter && carlistimg1) {
            centerpic.src = carlistimg1.src;
            centerpic.style.display = "flex";
            carnameCenter.innerHTML = "Car Name : " + carname1.innerHTML;
            carnameCenter.style.display = "flex";
            spawnedCarName = carname1.innerHTML;
            spawnedCarPrice = document.getElementById("carlistprice1").innerHTML;
        } else {
            //console.error("One or more elements not found in carlistrentbutton1 click handler.");
        }
    });

    $("#carlistrentbutton2").click(function() {
        let centerpic = document.getElementById("centerpic");
        let carnameCenter = document.getElementById("carnameCenter");
        let carname2 = document.getElementById("carname2");
        let carlistimg2 = document.getElementById("carlistimg2");

        if (centerpic && carnameCenter && carlistimg2) {
            centerpic.src = carlistimg2.src;
            centerpic.style.display = "flex";
            carnameCenter.innerHTML = "Car Name : " + carname2.innerHTML;
            carnameCenter.style.display = "flex";
            spawnedCarName = carname2.innerHTML;
            spawnedCarPrice = document.getElementById("carlistprice2").innerHTML;
        } else {
            //console.error("One or more elements not found in carlistrentbutton2 click handler.");
        }
    });

    $("#carlistrentbutton3").click(function() {
        let centerpic = document.getElementById("centerpic");
        let carnameCenter = document.getElementById("carnameCenter");
        let carname3 = document.getElementById("carname3");
        let carlistimg3 = document.getElementById("carlistimg3");

        if (centerpic && carnameCenter && carlistimg3) {
            centerpic.src = carlistimg3.src;
            centerpic.style.display = "flex";
            carnameCenter.innerHTML = "Car Name : " + carname3.innerHTML;
            carnameCenter.style.display = "flex";
            spawnedCarName = carname3.innerHTML;
            spawnedCarPrice = document.getElementById("carlistprice3").innerHTML;
        } else {
            //console.error("One or more elements not found in carlistrentbutton3 click handler.");
        }
    });

    $("#add").click(function() {
        if (counter < 12) {
            counter += 1;
            document.getElementById("timeText").innerHTML = counter;
        }
    });

    $("#sub").click(function() {
        if (counter > 0) {
            counter -= 1;
            document.getElementById("timeText").innerHTML = counter;
        }
    });

    $("#returnVehicle").click(function () {
        $.post('https://nom-carrentals/returnVehicle', JSON.stringify({}));
        clear();
    });

    $("#leftbutton").click(function() {
        if (counter > 0) {
            counter -= 5;
            document.getElementById("timeText").innerHTML = counter;

            // Change car prices
            for (let i = 1; i <= 5; i++) {
                let carPriceElement = document.getElementById("carlistprice" + i);
                if (carPriceElement) {
                    carPriceElement.innerHTML = parseInt(carPriceElement.innerHTML) - 20 + "$";
                } else {
                    //console.error("Element carlistprice" + i + " not found.");
                }
            }
        }
    });

    $("#rightbutton").click(function() {
        if (counter < 60) {
            counter += 5;
            document.getElementById("timeText").innerHTML = counter;

            // Change car prices
            for (let i = 1; i <= 5; i++) {
                let carPriceElement = document.getElementById("carlistprice" + i);
                if (carPriceElement) {
                    carPriceElement.innerHTML = parseInt(carPriceElement.innerHTML) + 20 + "$";
                } else {
                    //console.error("Element carlistprice" + i + " not found.");
                }
            }
        }
    });

    $(".car").click(function() {
        let centerpic = document.getElementById("centerpic");
        let carnameCenter = document.getElementById("carnameCenter");
        let carname = this.querySelector("h3");
        let carimg = this.querySelector(".carlistimg");

        if (centerpic && carnameCenter && carname && carimg) {
            centerpic.src = carimg.src;
            centerpic.style.display = "flex";
            carnameCenter.innerHTML = "Car Name : " + carname.innerHTML;
            carnameCenter.style.display = "flex";
            spawnedCarName = carname.innerHTML;
            spawnedCarPrice = this.querySelector(".carlistprice").innerHTML;
        } else {
            //console.error("One or more elements not found in car click handler.");
        }
    });
});