Config = {}

Config.Notify = "nom" -- Set to "nom" if you are using the nom-notify resource, else set to "false" for your default framework's notifications
Config.Blips = true -- Set to true if you want to display it, otherwise false if you do not want to display it
Config.Target = "target" -- Only use "target" if you use qb-target or ox_target, otherwise set to "textui"
Config.PaymentMethod = 'cash' -- Set this to "cash" to deduct cash or use "bank" to deduct the money from the player's account

Config.Settings = {
    locations = {
        [1] = {
            pedProps = {
                hash = 'a_m_y_business_02',
                location = vector4(-1033.93, -2733.07, 20.17, 328.26)
            },
            vehicleSpawnLocation = vector4(-1026.42, -2734.64, 19.38, 243.86)
        },
        [2] = {
            pedProps = {
                hash = 'a_m_y_business_02',
                location = vector4(-341.06, 267.64, 85.68, 195.47)
            },
            vehicleSpawnLocation = vector4(-349.22, 272.47, 84.43, 270.86)
        },
        -- add more locations as needed
    }
}

Config.Cars = {
    [1] = {
        ["car_name"] = "Club",
        ["car_price"] = 150,
    },
    [2] = {
        ["car_name"] = "Asterope",
        ["car_price"] = 300,
    },
    [3] = {
        ["car_name"] = "Aleutian",
        ["car_price"] = 800,
    },
    -- add more vehicles as needed but I would recommend stay on this
}

Config.RefundFee = 100
